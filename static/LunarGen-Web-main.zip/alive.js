const axios = require('axios');

function sendPing() {
  axios
    .get('https://faizur.onrender.com')
    .then((response) => {
      console.log(`Status Code: ${response.status}`);
    })
    .catch((error) => {
      console.error(`Error: ${error.message}`);
    });
}

// Send a ping every 59 seconds (59000 milliseconds)
setInterval(sendPing, 79000);

// Initial call to start immediately
sendPing();
