const moment = require('moment');

/**
 * Checks if the current time is within a given time slot.
 * @param {moment.Moment} currentTime - The current time as a moment object.
 * @param {string} startTime - The start time in HH:mm format.
 * @param {string} endTime - The end time in HH:mm format.
 * @returns {boolean} - True if the current time is within the time slot, otherwise false.
 */
function isWithinTimeSlot(currentTime, startTime, endTime) {
  if (!currentTime || !moment.isMoment(currentTime) || !currentTime.isValid()) {
    throw new Error('Invalid currentTime object. Ensure it is a valid moment instance.');
  }
  const start = moment(startTime, 'HH:mm');
  const end = moment(endTime, 'HH:mm');
  if (!start.isValid() || !end.isValid()) {
    throw new Error('Invalid startTime or endTime format. Use HH:mm format.');
  }
  return currentTime.isSameOrAfter(start) && currentTime.isBefore(end);
}

/**
 * Get the current time in IST (Indian Standard Time).
 * @returns {moment.Moment} - The current time as a moment object in IST.
 */
const GCTI2 = () => {
  return moment().utcOffset('+05:30');
};

module.exports = { isWithinTimeSlot, GCTI2 };
