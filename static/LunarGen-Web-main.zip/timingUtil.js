const moment = require('moment-timezone');

/**
 * Get the current time in Indian Standard Time (IST).
 * @returns {Date} Current date and time in IST.
 */
function getCurrentTimeInIST() {
  return moment().tz("Asia/Kolkata").toDate();
}

/**
 * Calculate the remaining time in seconds until the expiration time.
 * @param {Date} expirationTime - The expiration time to compare against.
 * @returns {number} Remaining time in seconds.
 */
function calculateRemainingTime(expirationTime) {
  const currentTime = getCurrentTimeInIST();
  return Math.max(0, Math.floor((expirationTime - currentTime) / 1000));
}

/**
 * Format the remaining time into HH:MM:SS.
 * @param {number} remainingTime - Time in seconds to format.
 * @returns {string} Formatted time string.
 */
function formatRemainingTime(remainingTime) {
  const hours = Math.floor(remainingTime / 3600);
  const minutes = Math.floor((remainingTime % 3600) / 60);
  const seconds = remainingTime % 60;

  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

module.exports = {
  getCurrentTimeInIST,
  calculateRemainingTime,
  formatRemainingTime,
};
