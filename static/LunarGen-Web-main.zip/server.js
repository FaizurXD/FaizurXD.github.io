const fs = require('fs').promises;
const path = require('path');
require("dotenv").config();
const express = require("express");
require("./alive.js");
const expressLayouts = require('express-ejs-layouts');
const mongoose = require("mongoose");
const axios = require("axios");
const link = require("linkvertise.js");
const ejs = require("ejs");
const User = require("./models/User");
const { getCurrentTimeInIST, calculateRemainingTime, formatRemainingTime } = require("./timingUtil");
const { isWithinTimeSlot, GCTI2 } = require('./timeSlotUtil');
// Additional dependencies for admin file manager
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;
const userId = process.env.LINKVERTISE_USER_ID;
const linkvertise = new link(userId);
const appURL = process.env.APP_URL;

// Admin credentials
const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const JWT_SECRET = process.env.JWT_SECRET;

app.set("view engine", "ejs");
app.set("views", "views");
app.use(express.static(path.join(__dirname, 'public')));
app.use(expressLayouts);
app.set("layout", "layout");

// Add middleware for parsing JSON and cookies
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

// Multer configuration for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const folder = req.params.folder;
      const uploadPath = path.join(__dirname, 'public', folder);
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    cb(null, true);
  }
});

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log("MongoDB connected successfully");
})
.catch(err => {
  console.error("MongoDB connection error:", err);
});

// Admin Authentication Middleware
function authenticateAdmin(req, res, next) {
  const token = req.cookies.adminToken;

  if (!token) {
    return res.redirect('/faizur/admin/login');
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role === 'admin') {
      next();
    } else {
      res.status(403).send('Access Denied');
    }
  } catch (error) {
    res.clearCookie('adminToken');
    res.redirect('/faizur/admin/login');
  }
}

// Admin Login Route
app.post('/faizur/admin/login', (req, res) => {
  const { username, password } = req.body;

  if (username === ADMIN_USERNAME && bcrypt.compareSync(password, bcrypt.hashSync(ADMIN_PASSWORD, 10))) {
    const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '1h' });
    res.cookie('adminToken', token, { 
      httpOnly: true, 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 3600000 // 1 hour
    });
    res.json({ success: true, message: 'Login successful' });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

// Helper function to list files
async function listFiles(folder) {
  const directoryPath = path.join(__dirname, 'public', folder);
  try {
    const files = await fs.readdir(directoryPath);
    const fileDetails = await Promise.all(files.map(async (file) => {
      const stats = await fs.stat(path.join(directoryPath, file));
      return {
        name: file,
        size: stats.size,
        lastModified: stats.mtime
      };
    }));
    return fileDetails;
  } catch (error) {
    console.error(`Error reading ${folder} directory:`, error);
    return [];
  }
}

// Admin Dashboard Route
app.get('/faizur/admin', authenticateAdmin, async (req, res) => {
  try {
    const stockFiles = await listFiles('stock');
    const pstockFiles = await listFiles('pstock');

    res.render('admin/dashboard', { 
      stockFiles, 
      pstockFiles 
    });
  } catch (error) {
    console.error('Error listing files:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Login Page Route
app.get('/faizur/admin/login', (req, res) => {
  res.render('admin/login');
});

// File Upload Route
app.post('/faizur/admin/upload/:folder', authenticateAdmin, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }
  res.redirect('/faizur/admin');
});

// File Delete Route
app.delete('/faizur/admin/delete/:folder/:filename', authenticateAdmin, async (req, res) => {
  const { folder, filename } = req.params;
  const filePath = path.join(__dirname, 'public', folder, filename);

  try {
    await fs.unlink(filePath);
    res.json({ success: true, message: 'File deleted successfully' });
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({ success: false, message: 'Error deleting file' });
  }
});

// File Download Route
app.get('/faizur/admin/download/:folder/:filename', authenticateAdmin, (req, res) => {
  const { folder, filename } = req.params;
  const filePath = path.join(__dirname, 'public', folder, filename);

  res.download(filePath, filename, (err) => {
    if (err) {
      console.error('Download error:', err);
      res.status(404).send('File not found');
    }
  });
});

// Existing routes from your original code...
function generateToken() {
  const length = 50;
  const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
  let token = "";
  for (let i = 0, n = charset.length; i < length; ++i) {
    token += charset.charAt(Math.floor(Math.random() * n));
  }
  return token;
}

app.get('/', (req, res) => {
  res.render('index');
});

app.get("/earn/:user/:otp", async (req, res) => {
  try {
    const user = req.params.user;
    const otp = req.params.otp;
    const redirectURL = `${appURL}/redirect/${user}/${otp}`;
    res.render("start", { url: redirectURL });
  } catch (error) {
    console.error("Error in /earn route:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/redirect/:user/:otp", async (req, res) => {
  try {
    const user = req.params.user;
    const otp = req.params.otp;
    const token = generateToken();
    const url = `${appURL}/verify/${user}/${otp}/${token}`;
    const shrink = await linkvertise.shrink(url);
    res.redirect(shrink);
  } catch (error) {
    console.error("Error in /redirect route:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/verify/:user/:otp/:token", async (req, res) => {
  try {
    const { user, otp, token } = req.params;
    const hash = req.query.hash;

    if (!hash) {
      return res.sendFile(path.join(__dirname, "public", "bypass.html"));
    }

    const authToken = process.env.LINKVERTISE_AUTH_TOKEN;
    const apiEndpoint = `https://publisher.linkvertise.com/api/v1/anti_bypassing`;

    const response = await fetch(`${apiEndpoint}?token=${authToken}&hash=${hash}`, {
      method: "POST",
    });
    const { status } = await response.json();

    if (!status) {
      return res.sendFile(path.join(__dirname, "public", "bypass.html"));
    }

    const earnedTime = parseInt(process.env.USAGE_TIME);
    let userRecord = await User.findOne({ userId: user });
    const currentTime = getCurrentTimeInIST();
    let newExpirationTime;

    if (!userRecord) {
      newExpirationTime = new Date(currentTime.getTime() + earnedTime * 60 * 1000);
      userRecord = new User({ userId: user, expirationTime: newExpirationTime });
    } else {
      if (userRecord.expirationTime > currentTime) {
        newExpirationTime = new Date(userRecord.expirationTime.getTime() + earnedTime * 60 * 1000);
      } else {
        newExpirationTime = new Date(currentTime.getTime() + earnedTime * 60 * 1000);
      }
      userRecord.expirationTime = newExpirationTime;
    }

    await userRecord.save();
    res.render("success", { userId: user, expirationTime: newExpirationTime });
  } catch (error) {
    console.error("Error in /verify route:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/checkGenTime/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    const user = await User.findOne({ userId });
    const currentTime = getCurrentTimeInIST();

    if (user && user.expirationTime > currentTime) {
      const remainingTime = calculateRemainingTime(user.expirationTime);
      res.json({
        hasGenTime: true,
        remainingTime: remainingTime,
        formattedTime: formatRemainingTime(remainingTime),
      });
    } else {
      res.json({
        hasGenTime: false,
        remainingTime: 0,
        formattedTime: "00:00:00",
      });
    }
  } catch (error) {
    console.error("Error in /checkGenTime route:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/404", (req, res) => {
  try {
    res.render("404");
  } catch (error) {
    console.error("Error in /404 route:", error);
    res.status(500).send("Internal Server Error");
  }
});

const ads = [
  {
    bannerUrl: 'https://i.ibb.co/SrVHpHh/20241226-033513.png',
    bannerAlt: 'AD',
    clickUrl: 'https://discord.gg/7x7wyGuMqw',
    startTime: '00:00',
    endTime: '07:59',
  },
  {
    bannerUrl: 'https://i.ibb.co/SrVHpHh/20241226-033513.png',
    bannerAlt: 'AD',
    clickUrl: 'https://discord.gg/7x7wyGuMqw',
    startTime: '08:00',
    endTime: '15:59',
  },
  {
    bannerUrl: 'https://i.ibb.co/SrVHpHh/20241226-033513.png',
    bannerAlt: 'AD',
    clickUrl: 'https://discord.gg/7x7wyGuMqw',
    startTime: '16:00',
    endTime: '23:59',
  },
];

app.get('/etc/ads', (req, res) => {
  try {
    const currentTime = GCTI2();
    const activeAd = ads.find(ad => isWithinTimeSlot(currentTime, ad.startTime, ad.endTime));

    if (activeAd) {
      res.json({
        success: true,
        bannerUrl: activeAd.bannerUrl,
        bannerAlt: activeAd.bannerAlt,
        clickUrl: activeAd.clickUrl,
      });
    } else {
      res.json({
        success: false,
        message: 'No ad available for the current time slot.',
      });
    }
  } catch (error) {
    console.error('Error fetching ad:', error.message);
    res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
});

const userInfoApiMiddleware = (req, res, next) => {
    const authKey = req.headers['auth-key'];
    if (!authKey || authKey !== process.env.AUTH_KEY) {
        return res.status(401).json({ error: 'Unauthorized: Invalid or missing AUTH_KEY' });
    }
    next();
};

app.get('/api/get/info', userInfoApiMiddleware, async (req, res) => {
    try {
        const { userId } = req.query;
        if (!userId) {
            return res.status(400).json({ error: 'Missing userId parameter' });
        }

        const response = await axios.get(`https://discord.com/api/v10/users/${userId}`, {
            headers: { 'Authorization': `Bot ${process.env.token}` }
        });

        const user = response.data;
        const avatarUrl = user.avatar 
            ? `https://cdn.discordapp.com/avatars/${userId}/${user.avatar}.png`
            : `https://cdn.discordapp.com/embed/avatars/${parseInt(user.discriminator) % 5}.png`;

        res.json({
            username: user.username,
            profileImage: avatarUrl
        });

    } catch (error) {
        if (error.response?.status === 404) {
            return res.status(404).json({ error: 'Discord user not found' });
        }
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.listen(port, () => {
  console.log(`Application listening on port ${port}!`);
});
