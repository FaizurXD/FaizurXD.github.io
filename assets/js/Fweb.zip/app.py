from flask import Flask, render_template, request, Response, redirect, url_for
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

app = Flask(__name__)

# User-Agent dictionary for desktop and mobile modes
USER_AGENTS = {
    'desktop': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
    'mobile': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
}

def get_user_agent(mode):
    return USER_AGENTS.get(mode, USER_AGENTS['desktop'])  # Default to desktop User-Agent

def rewrite_links(html_content, base_url, proxy_url):
    soup = BeautifulSoup(html_content, 'html.parser')

    # Rewriting links for scripts, CSS, images, and anchors
    for tag in soup.find_all(['script', 'link', 'img', 'a']):
        if tag.name == 'script' and tag.get('src'):
            tag['src'] = urljoin(base_url, tag['src'])
        elif tag.name == 'link' and tag.get('href'):
            tag['href'] = urljoin(base_url, tag['href'])
        elif tag.name == 'img' and tag.get('src'):
            tag['src'] = urljoin(base_url, tag['src'])
        elif tag.name == 'a' and tag.get('href'):
            href = tag['href']
            if not href.startswith('#'):  # Avoid internal page anchor links
                tag['href'] = f"{proxy_url}?url={urljoin(base_url, href)}"

    return str(soup)

@app.route('/')
def index():
    # Home page to input URL
    return render_template('index.html')

@app.route('/proxy', methods=['POST', 'GET'])
def proxy():
    if request.method == 'POST':
        # Get the URL and mode (desktop/mobile) from the form
        user_url = request.form['url']
        user_mode = request.form.get('mode', 'desktop')
    else:
        # Get URL from query parameters if using GET
        user_url = request.args.get('url')
        user_mode = request.args.get('mode', 'desktop')

    if not user_url:
        return redirect(url_for('index'))

    # Ensure URL starts with http/https
    if not user_url.startswith(('http://', 'https://')):
        user_url = f"https://{user_url}"

    try:
        # Set up the headers and send the request
        headers = {'User-Agent': get_user_agent(user_mode)}
        response = requests.get(user_url, headers=headers)

        if response.status_code == 200:
            content = response.text
            base_url = response.url  # Get the actual base URL (in case of redirects)
            proxy_url = request.url_root + 'proxy'  # Current proxy URL

            # Rewrite all links in the fetched content
            rewritten_content = rewrite_links(content, base_url, proxy_url)

            # Return the modified HTML content
            return Response(rewritten_content, content_type='text/html')

        else:
            return f"Error: Unable to fetch the page (Status Code: {response.status_code})"

    except requests.RequestException as e:
        return f"Failed to fetch URL: {e}"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)