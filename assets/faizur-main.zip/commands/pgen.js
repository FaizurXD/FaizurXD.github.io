// Dependencies
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const config = require('../config.json');
const CatLoggr = require('cat-loggr');

// Made By ScienceGear#4409 Youtube https://www.youtube.com/c/ScienceGearYT
// Functions
const log = new CatLoggr();
const generated = new Set();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('pgen')
        .setDescription('Generate a specified service if stocked (premium)')
        .addStringOption(option =>
            option.setName('service')
                .setDescription('The service you want to generate')
                .setRequired(true)),

    /**
     * Command execute
     * @param {Interaction} interaction The interaction object
     */
    async execute(interaction) {
        // If the generator channel is not given in config or invalid
        try {
            interaction.client.channels.cache.get(config.pgenChannel).id; // Try to get the channel's id
        } catch (error) {
            if (error) log.error(error); // If an error occurred, log to console

            // Send error message if the "error_message" field is "true" in the configuration
            if (config.command.error_message === true) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('Error occurred!')
                            .setDescription('Not a valid gen channel specified!')
                            .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            } else return;
        }

        // If the interaction happens in the generator channel as per the configuration
        if (interaction.channel.id === config.pgenChannel) {
            // If the user has cooldown on the command
            if (generated.has(interaction.user.id)) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('Cooldown!')
                            .setDescription(`Please wait **${config.genCooldownsec}** seconds before executing that command again!`)
                            .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            } else {
                // Get the service parameter
                const service = interaction.options.getString('service');

                // File path to find the given service
                const filePath = `${__dirname}/../pstock/${service}.txt`;

                // Read the service file
                fs.readFile(filePath, function (error, data) {
                    // If no error
                    if (!error) {
                        data = data.toString(); // Stringify the content
                        const position = data.indexOf('\n'); // Get position
                        const firstLine = data.split('\n')[0]; // Get the first line

                        // If the service file is empty
                        if (position === -1) {
                            return interaction.reply({
                                embeds: [
                                    new MessageEmbed()
                                        .setColor(config.color.red)
                                        .setTitle('Generator error!')
                                        .setDescription(`I do not find the \`${service}\` service in my stock!`)
                                        .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                                        .setTimestamp()
                                ],
                                ephemeral: true
                            });
                        }

                        // Send messages to the user
                        interaction.user.send({
                            embeds: [
                                new MessageEmbed()
                                    .setColor(config.color.green)
                                    .setTitle('Generated account')
                                    .addField('Service', `\`\`\`${service[0].toUpperCase()}${service.slice(1).toLowerCase()}\`\`\``, true)
                                    .addField('Account', `\`\`\`${firstLine}\`\`\``, true)
                                    .setTimestamp()
                            ]
                        });

                        // Remove the generated account line
                        if (position !== -1) {
                            data = data.substr(position + 1); // Remove the generated account line
                            
                            // Write changes
                            fs.writeFile(filePath, data, function (writeError) {
                                if (writeError) return log.error(writeError); // Log write error

                                interaction.reply({
                                    embeds: [
                                        new MessageEmbed()
                                            .setColor(config.color.green)
                                            .setTitle('Account generated successfully!')
                                            .setDescription(`Check your private ${interaction.user}! *If you do not receive the message, please unlock your private messages!*`)
                                            .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                                            .setTimestamp()
                                    ],
                                    ephemeral: true
                                });

                                generated.add(interaction.user.id); // Add user to the cooldown set

                                // Set cooldown time
                                setTimeout(() => {
                                    generated.delete(interaction.user.id); // Remove the user from the cooldown set after the cooldown expires
                                }, config.genCooldown);
                            });
                        } else {
                            // If the service is empty
                            return interaction.reply({
                                embeds: [
                                    new MessageEmbed()
                                        .setColor(config.color.red)
                                        .setTitle('Generator error!')
                                        .setDescription(`The \`${service}\` service is empty!`)
                                        .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                                        .setTimestamp()
                                ],
                                ephemeral: true
                            });
                        }
                    } else {
                        // If the service does not exist
                        return interaction.reply({
                            embeds: [
                                new MessageEmbed()
                                    .setColor(config.color.red)
                                    .setTitle('Generator error!')
                                    .setDescription(`Service \`${service}\` does not exist!`)
                                    .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                                    .setTimestamp()
                            ],
                            ephemeral: true
                        });
                    }
                });
            }
        } else {
            // If the command executed in another channel
            interaction.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(config.color.red)
                        .setTitle('Wrong command usage!')
                        .setDescription(`You cannot use the \`pgen\` command in this channel! Try it in <#${config.pgenChannel}>!`)
                        .setFooter(interaction.user.tag, interaction.user.displayAvatarURL({ dynamic: true, size: 64 }))
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }
    }
};