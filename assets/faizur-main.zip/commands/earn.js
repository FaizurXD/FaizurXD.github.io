const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const crypto = require('crypto');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('earn')
        .setDescription('Use this to earn generation time, which adds up.'),

    async execute(interaction) {
        const userId = interaction.user.id;

        // Generate a random 16-character alphanumeric hash
        const hash = crypto.randomBytes(8).toString('hex'); // 8 bytes = 16 hex characters

        // Get the app URL from the environment variable
        const appUrl = process.env.APP_URL;

        // Construct the URL
        const earnUrl = `${appUrl}/earn/${userId}/${hash}`;

        // Send the URL back to the user
        const embed = new MessageEmbed()
            .setColor('#0099ff')
            .setTitle('Your Earn URL')
            .setDescription(`Here is your URL to earn Gen Time : [Click Here](${earnUrl})`)
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
