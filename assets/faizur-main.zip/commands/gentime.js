const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const axios = require('axios');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gentime')
        .setDescription('Check your remaining generation time.'),

    async execute(interaction) {
        const userId = interaction.user.id;

        // Construct the URL for the POST request
        const url = `${process.env.APP_URL}/checkGenTime/${userId}`;

        try {
            // Send POST request to check generation time
            const response = await axios.post(url);
            const data = response.data;

            // Check the response and send appropriate messages
            if (data.hasGenTime) {
                const remainingTimeInSeconds = data.remainingTime;
                
                // Convert remaining time (in seconds) to hours and minutes
                const remainingHours = Math.floor(remainingTimeInSeconds / 3600);
                const remainingMinutes = Math.floor((remainingTimeInSeconds % 3600) / 60);

                // Format the time string
                const formattedTime = `${remainingHours} hour${remainingHours !== 1 ? 's' : ''} ${remainingMinutes} minute${remainingMinutes !== 1 ? 's' : ''}`;

                const embed = new MessageEmbed()
                    .setColor('#00ff00')
                    .setTitle('Generation Time :')
                    .setDescription(`You have **${formattedTime}** of generation time left.`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed], ephemeral: true });
            } else {
                await interaction.reply({ content: 'You do not have any remaining generation time.', ephemeral: true });
            }
        } catch (error) {
            console.error('Error checking generation time:', error);
            await interaction.reply({ content: 'An error occurred while checking your generation time.', ephemeral: true });
        }
    },
};
