const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const crypto = require('crypto');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('getkey')
        .setDescription('Use this to generate a key URL for earning generation time.'),

    async execute(interaction) {
        const userId = interaction.user.id;

        // Generate a random 16-character alphanumeric hash
        const hash = crypto.randomBytes(8).toString('hex'); // 8 bytes = 16 hex characters

        // Get the app URL from the environment variable
        const appUrl = process.env.APP_URL;

        // Construct the URL
        const getKeyUrl = `${appUrl}/earn/${userId}/${hash}`;

        // Send the URL back to the user
        const embed = new MessageEmbed()
            .setColor('#0099ff')
            .setTitle('Your Key URL')
            .setDescription(`Here is your key URL For earning gen Time: [Click Here](${getKeyUrl})`)
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
