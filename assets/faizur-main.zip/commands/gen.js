const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const config = require('../config.json');
const CatLoggr = require('cat-loggr');
const axios = require('axios');
const log = new CatLoggr();
const generated = new Set();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gen')
        .setDescription('Generate a specified service if stocked.')
        .addStringOption(option => {
            const serviceFiles = fs.readdirSync(`${__dirname}/../stock`).filter(file => file.endsWith('.txt'));
            const availableServices = serviceFiles.map(file => file.replace('.txt', ''));
            
            option.setName('service')
                .setDescription('Select the service to generate')
                .setRequired(true);

            availableServices.forEach(service => {
                option.addChoices({ name: service, value: service });
            });

            return option;
        }),

    async execute(interaction) {
        try {
            const genChannel = interaction.client.channels.cache.get(config.genChannel)?.id;
            if (!genChannel) throw new Error('Invalid gen channel specified');

            if (interaction.channel.id !== genChannel) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('Wrong command usage!')
                            .setDescription(`Use the \`gen\` command in <#${config.genChannel}>!`)
                            .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            const hasGenTime = await checkGenerationTime(interaction.user.id);
            if (!hasGenTime.allowed) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('No Generation Time!')
                            .setDescription(`You need more generation time. Please wait **${hasGenTime.remainingTime}** seconds or use **/earn** to gain more time.`)
                            .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            if (generated.has(interaction.user.id)) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('Cooldown!')
                            .setDescription(`Please wait **${config.genCooldownsec}** seconds before using that command again!`)
                            .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            const service = interaction.options.getString('service');
            const filePath = `${__dirname}/../stock/${service}.txt`;
            fs.readFile(filePath, 'utf8', (error, data) => {
                if (error) {
                    return interaction.reply({
                        embeds: [
                            new MessageEmbed()
                                .setColor(config.color.red)
                                .setTitle('Generator error!')
                                .setDescription(`Service \`${service}\` does not exist!`)
                                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                                .setTimestamp()
                        ],
                        ephemeral: true
                    });
                }

                const firstLine = data.split('\n')[0];
                if (!firstLine) {
                    return interaction.reply({
                        embeds: [
                            new MessageEmbed()
                                .setColor(config.color.red)
                                .setTitle('Generator error!')
                                .setDescription(`The \`${service}\` service is empty!`)
                                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                                .setTimestamp()
                        ],
                        ephemeral: true
                    });
                }

                // Send DM with credentials to the user
                interaction.user.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.green)
                            .setTitle(`Account Generated for ${interaction.user.username}`)
                            .setDescription(`Here are your credentials for **${service}**:\n\`\`\`${firstLine}\`\`\``)
                            .setFooter({ text: '© Faizur' })
                            .setThumbnail(interaction.guild.iconURL())
                            .setTimestamp()
                    ]
                }).then(() => {
                    // Reply in the channel confirming generation success
                    interaction.reply({
                        embeds: [
                            new MessageEmbed()
                                .setColor(config.color.green)
                                .setTitle(`Your \`${service}\` account has been sent.`)
                                .setDescription(` \u200B \n\n\`\`\`${service}\`\`\`\n\nCheck Your DM to continue. If you haven't received DM, please ensure your DMs are enabled.`)
                                .setFooter({ text: '© Faizur' })
                                .setThumbnail(interaction.guild.iconURL())
                                .setTimestamp()
                        ]
                    });

                    // Remove the used credential from the stock file
                    const remainingData = data.split('\n').slice(1).join('\n');
                    fs.writeFile(filePath, remainingData, (err) => {
                        if (err) log.error(err);
                    });

                    // Add cooldown for user
                    generated.add(interaction.user.id);
                    setTimeout(() => generated.delete(interaction.user.id), config.genCooldown * 1000);
                }).catch(() => {
                    // Inform user if DM couldn't be sent
                    interaction.reply({
                        embeds: [
                            new MessageEmbed()
                                .setColor(config.color.red)
                                .setTitle('DM Failed')
                                .setDescription(`I couldn't send you the account in DMs, ${interaction.user}. Please enable DMs and try again.`)
                                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                                .setTimestamp()
                        ],
                        ephemeral: true
                    });
                });
            });
        } catch (error) {
            log.error(error);
            if (config.command.error_message) {
                return interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(config.color.red)
                            .setTitle('Error occurred!')
                            .setDescription('An error occurred while processing your request. Please try again later.')
                            .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }
        }
    }
};

async function checkGenerationTime(userId) {
    try {
        const response = await axios.get(`https://faizur.onrender.com/checkGenTime/${userId}`);
        const data = response.data;
        return {
            allowed: data.hasGenTime,
            remainingTime: data.remainingTime || 0
        };
    } catch (error) {
        log.error('Error checking generation time:', error);
        return { allowed: false, remainingTime: 0 };
    }
}
